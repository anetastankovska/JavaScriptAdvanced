BeerApp is a simple page that contains information about different types of beers. 
It has three links in the navigation bar and a search bar
1. The first link "BeerBar" is the home page where the application greets the user. 

2. The second link "Beers" shows information about all beers.
- Two features are added to this page: "Show" and "Sort by". 
    * "Show" drop-down menu lets us pick how many beers should appear on a single page. 
description     * "Sort by" drop-down menu lets us sort the beers by: name, alcohol, date whet it was first brewed and bitterness.
- At the bottom of the page appear two buttons that let the user navigate through pages via "Previous page" and "Next page" buttons.

3. The third link "RandomBeer" picks a beer randomly and shows detailed information about the beers. The user can return to the "Beers" page by clicking to "Back to beers" button.

The search bar searches by a letter or a keyword contained in the name of the beer.